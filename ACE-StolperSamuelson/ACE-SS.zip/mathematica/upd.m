(* ::Package:: *)

(**Updater **)
citizensi=Rationalize[consumerEach];
citizenss=Rationalize[consumerEach];
pizzaPreferencei = pizzaPreference;
pizzaPreferences=pizzaPreferencei ;
firmsf=Rationalize[firmsPerGood];
firmsp=Rationalize[firmsPerGood];
sprodf=Rationalize[highProductivity]; 
sprodp=10-sprodf;
iprodp=Rationalize[highProductivity];
iprodf=10-iprodp;
prefpi=Rationalize[pizzaPreferencei]
prefps=Rationalize[pizzaPreferences]
preffs=10-prefps;
preffi=10-prefpi;
