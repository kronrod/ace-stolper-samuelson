// Created by Luzius on Apr 28, 2014

package com.abs.market;

public interface IPriceMakerMarket {
	
	public void offer(AbstractOffer offer);

}
