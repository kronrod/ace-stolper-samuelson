// Created by Luzius on Jun 22, 2014

package com.abs.firm;

public interface IPrice {

	public double getPrice();

	public void adapt(boolean increasePrice);

}
